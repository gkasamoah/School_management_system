import {React} from "react";
const Signup=()=>{
    return(
        <div>
          <button className=" bg-teal-400 m-3 w-32 h-8 hover:bg-black  hover:text-white"><a href="/SignupIndex">Sign Up</a></button>

        </div>
    )

    
}
export default Signup