import {React}from "react"
import AdminDashboardComp from "../components/AdminDashboardComp"
const AdminDashboard=()=>{
 return(
    <div>
     <AdminDashboardComp/>
    </div>
 )
}
 export default AdminDashboard