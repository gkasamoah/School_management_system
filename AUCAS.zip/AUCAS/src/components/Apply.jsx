import {React} from "react";

const Apply=()=>{
    return(
        <div>
          <button className=" bg-teal-400 h-8 m-3 w-24  hover:bg-black hover:text-white "><a href="/">Apply</a></button>

        </div>
    )

    
}
export default Apply