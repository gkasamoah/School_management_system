import {React} from "react";
const Header=()=>{
    return(
        <div>
         <div className=" ml-8">
         <a href="/"><img src="src/IMG-20230923-WA0002.jpg" alt="Logo" style={{height:"50px"}} /></a> 

         <div><img src="src/IMG-20230926-WA0031(1).jpg"  className="  right-12 h-8 fixed top-0" alt="" /> </div>
         </div>

        </div>
    )

    
}
export default Header