import {React} from "react";
const Institution=()=>{




    return(
        <div>
          <button className=" bg-teal-400 border-2 h-8 m-3 w-20 rounded-lg  hover:bg-black hover:text-white"><a href="/Index/Institutionpage">Institution</a></button>

        </div>
    )

    
}
export default Institution