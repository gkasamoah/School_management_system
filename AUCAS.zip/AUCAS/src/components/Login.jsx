import {React} from "react";
const Login=()=>{
    return(
        <div>
          <button className=" border-teal-400 border-2 h-8 m-3 w-16  hover:bg-black hover:text-white "><a href="/Index">Login</a></button>

        </div>
    )

    
}
export default Login