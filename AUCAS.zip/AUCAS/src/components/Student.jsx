import {React} from "react";
const Student=()=>{
    return(
        <div>
          <button className=" border-teal-400 border-2 h-8 m-3 w-16 rounded-lg hover:bg-black hover:text-white "><a href="/Index/Studentpage">Student</a></button>

        </div>
    )

    
}
export default Student