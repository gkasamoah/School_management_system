import {React} from "react";
const StudentSignup=()=>{




    return(
        <div>
          <button className=" bg-teal-400 border-2 h-8 m-3 w-20 rounded-lg  hover:bg-black hover:text-white"><a href="/Studentregister">Student</a></button>

        </div>
    )

    
}
export default StudentSignup